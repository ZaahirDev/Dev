﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestGetUsersAndFollowers()
        {
            TwitterFeed.TwitterFeed.MainMenu("1");
        }
        [TestMethod]
        public void TestGetUsersAndTweets()
        {
            TwitterFeed.TwitterFeed.MainMenu("2");
        }
        [TestMethod]
        public void TestExit()
        {
            TwitterFeed.TwitterFeed.MainMenu("3");
        }
    }
}
