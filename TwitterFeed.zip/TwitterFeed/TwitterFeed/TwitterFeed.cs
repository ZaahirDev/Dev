﻿using System;
using TwitterFeed.Common;

namespace TwitterFeed
{
    public class TwitterFeed
    {
        /// <summary>
        /// Displays the Main Menu
        /// </summary>
        /// <param name="args"></param>
        [STAThread]
        static void Main(string[] args)
        {
            try
            {
               #region Show Main Menu
                bool showMenu = true;
                while (showMenu)
                {
                    showMenu = MainMenu();
                }
                if (!showMenu)
                {
                    Console.WriteLine("Thank you, Good Bye!");
                }
                #endregion
            }
            catch (Exception ex)
            {
                ExceptionHelper exHelper = new ExceptionHelper();
                exHelper.LogException(ex.ToString(), "TwitterFeed > Main");
            }

        }
        /// <summary>
        /// Co-ordinates which class method to invoke, based on the users input
        /// </summary>
        /// <returns></returns>
        public static bool MainMenu(string UnitTestValue = "")
        {
            bool outcome = false;
            try
            {
                DisplayHelper displayHelper = new DisplayHelper();
                var option = string.Empty;
                bool isUnitTest = false;

                Console.WriteLine("Please select an option below:" + Environment.NewLine +
                                  "1. Users and there follower's" + Environment.NewLine +
                                  "2. Users and the Tweets" + Environment.NewLine +
                                  "3. Exit");
                if (!string.IsNullOrEmpty(UnitTestValue))
                {
                    option = UnitTestValue;
                    isUnitTest = true;
                }
                else
                {
                    option = Console.ReadLine();
                }

                switch (option)
                {
                    case "1":
                        Console.Clear();
                        outcome = displayHelper.GetUsersAndFollowers(isUnitTest);
                        break;
                    case "2":
                        Console.Clear();
                        outcome = displayHelper.GetUsersAndTweets(isUnitTest);
                        break;
                    case "3":
                        outcome = false;
                        break;
                    default:
                        Console.Clear();
                        Console.WriteLine("Invalid option, please select 1, 2 or 3");
                        return true;
                 }

                Console.Clear();
                return outcome;
            }
            catch (Exception ex)
            {
                ExceptionHelper exHelper = new ExceptionHelper();
                exHelper.LogException(ex.ToString(), "TwitterFeed > Main");
                return outcome;
            }
            
            
        }
    }
}
