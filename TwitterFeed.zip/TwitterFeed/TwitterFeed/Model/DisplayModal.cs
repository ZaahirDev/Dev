﻿using System.Collections.Generic;

namespace TwitterFeed.Model
{
    public class DisplayModal
    {
        public string User { get; set; }
        public List<string> Tweet { get; set; }
    }
}
