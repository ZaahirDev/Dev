﻿namespace TwitterFeed.Model
{
    public class UserModel
    {
        public string UserName { get; set; }
        public string Action { get; set; }
        public string FollowedUsers { get; set; }
    }
}
