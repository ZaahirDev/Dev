﻿namespace TwitterFeed.Model
{
    public class TwitterModel
    {
        public string UserName { get; set; }
        public string Tweet { get; set; }
    }
}
