﻿using System;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using TwitterFeed.Common;

namespace TwitterFeed
{
    /// <summary>
    /// 1.Prompts the user to select the user and/or twitter text file
    /// 2.Validates the data in the file for both the user and twitter file
    /// 3.Saves the file paths to variables to be used in rest of the solution 
    /// </summary>
    public class FileHelper
    {
        public static string UserFilePath { get; private set; }
        public static string TwitterFilePath { get; private set; }
        /// <summary>
        /// 1. Gets the User File via FileDialog
        /// 2. Validates if the data in the file is in the correct structure 
        /// </summary>
        /// <param name="isUnitTest"></param>
        /// <returns></returns>
        public static bool GetUsersFile(bool isUnitTest = false)
        {
            try
            {
                #region Uploading and Validating user file
                var userInput_User = string.Empty;

                Console.WriteLine("Please Upload the user text file by, selecting any key on the keyboard:");
                if (isUnitTest)
                {
                    userInput_User = "Unit Test";
                }
                else
                {
                    userInput_User = Console.ReadLine();
                }

                if (!string.IsNullOrEmpty(userInput_User))
                {
                    var userFilePath = LaunchFileDialog().ToString();
                    if (!string.IsNullOrEmpty(userFilePath))
                    {
                        if (!DataValidation(userFilePath, "user"))
                        {
                            Console.Clear();
                            Console.WriteLine("The data in the file for User(s) is invalid, the structure should be as follows:"
                                              + Environment.NewLine + "Ward follows Alan");
                            return true;
                        }
                        else
                        {
                            Console.Clear();
                            Console.WriteLine("Path to the User(s) file: " + userFilePath);
                            UserFilePath = userFilePath;

                        }
                    }
                    else if (string.IsNullOrEmpty(userFilePath))
                    {
                        Console.Clear();
                        Console.WriteLine("Invalid, lets start over!");
                        return true;
                    }

                }
                else if (string.IsNullOrEmpty(userInput_User))
                {
                    Console.Clear();
                    Console.WriteLine("Invalid, lets start over!");
                    return true;
                }
                return false;
                #endregion
            }
            catch (Exception ex)
            {
                ExceptionHelper exHelper = new ExceptionHelper();
                exHelper.LogException(ex.ToString(), "FileHelper > GetUsersFile");
                return false;
            }
        }
        /// <summary>
        /// 1. Gets the twitter File via FileDialog
        /// 2. Validates if the data in the file is in the correct structure 
        /// </summary>
        /// <param name="isUnitTest"></param>
        /// <returns></returns>
        public static bool GetUsersAndTweetsFile(bool isUnitTest = false)
        {
            try
            {
                #region Getting and Validating user file
                var userInput_User = string.Empty;
                var userFilePath = string.Empty;
                var twitterFilePath = string.Empty;

                Console.WriteLine("Please Upload the user text file by, selecting any key on the keyboard:");
                if (isUnitTest)
                {
                    userInput_User = "Unit Test";
                }
                else
                {
                    userInput_User = Console.ReadLine();
                }

                if (!string.IsNullOrEmpty(userInput_User))
                {
                    userFilePath = LaunchFileDialog().ToString();
                    if (!string.IsNullOrEmpty(userFilePath))
                    {
                        if (!DataValidation(userFilePath, "user"))
                        {
                            Console.Clear();
                            Console.WriteLine("The data in the file for User(s) is invalid, the structure should be as follows:"
                                              + Environment.NewLine + "Ward follows Alan");
                            return true;
                        }
                        else
                        {
                            Console.Clear();
                            UserFilePath = userFilePath;

                        }
                    }
                    else if (string.IsNullOrEmpty(userFilePath))
                    {
                        Console.Clear();
                        Console.WriteLine("Invalid, lets start over!");
                        return true;
                    }

                }
                else if (string.IsNullOrEmpty(userInput_User))
                {
                    Console.Clear();
                    Console.WriteLine("Invalid, lets start over!");
                    return true;
                }
                #endregion

                #region Getting and Validating Twitter file
                var userInput_Twitter = string.Empty;
                Console.WriteLine("Perfect, now lets do the same for the Twitter file:");
                if (isUnitTest)
                {
                    userInput_Twitter = "Unit Test";
                }
                else
                {
                    userInput_Twitter = Console.ReadLine();
                }

                if (!string.IsNullOrEmpty(userInput_Twitter))
                {
                    twitterFilePath = LaunchFileDialog().ToString();
                    if (!string.IsNullOrEmpty(twitterFilePath))
                    {
                        if (!DataValidation(twitterFilePath, "twitter"))
                        {
                            Console.Clear();
                            Console.WriteLine("The data in the file for Twitter is invalid, the structure should be as follows:"
                                              + Environment.NewLine + "Alan> .NET Rocks!");
                            return true;
                        }
                        else
                        {
                            Console.Clear();

                            TwitterFilePath = twitterFilePath;

                        }
                    }
                    else if (string.IsNullOrEmpty(twitterFilePath))
                    {
                        Console.Clear();
                        Console.WriteLine("Invalid, lets start over!");
                        return true;
                    }
                }
                else if (string.IsNullOrEmpty(userInput_Twitter))
                {
                    Console.Clear();
                    Console.WriteLine("Invalid, lets start over!");
                    return true;
                }
                //Displays the path for both text files
                Console.WriteLine("User file path: " + userFilePath);
                Console.WriteLine("Twitter file path: " + twitterFilePath);
                return false;
                #endregion
            }
            catch (Exception ex)
            {
                ExceptionHelper exHelper = new ExceptionHelper();
                exHelper.LogException(ex.ToString(), "FileHelper > GetUsersAndTweetsFile");
                return false;
            }

        }
        /// <summary>
        /// Method used to launch the File Dialog and restricts the user to only select .txt file extensions
        /// </summary>
        /// <returns></returns>
        [STAThread]
        public static string LaunchFileDialog()
        {
            OpenFileDialog fd = new OpenFileDialog
            {
                Filter = "Text files (*.txt)|*.txt" 
            };
            fd.ShowDialog();
            return fd.FileName;
        }
        /// <summary>
        /// Validates if the data in the file is in the expected format
        /// </summary>
        /// <param name="path"></param>
        /// <param name="validationFile"></param>
        /// <returns></returns>
        public static bool DataValidation(string path, string validationFile)
        {
            bool isDataValid = true;
            if (validationFile.Equals("user"))//Validates the user file
            {
                foreach (var line in File.ReadLines(path))
                {
                    Match match = Regex.Match(line, "[^a-z0-9-, ]",
                        RegexOptions.IgnoreCase);

                    if (match.Success)
                    {
                        isDataValid = false;
                        break;
                    }
                }

            }
            else if (validationFile.Equals("twitter"))//Validates the twitter file
            {
                int counter = 0;
                foreach (var line in File.ReadLines(path))
                {
                    counter = line.Count(a => (a == '>'));
                    if (counter < 1 || counter > 1)
                    {
                        isDataValid = false;
                        break;
                    }
                }
            }
            return isDataValid;
        }
    }
}
