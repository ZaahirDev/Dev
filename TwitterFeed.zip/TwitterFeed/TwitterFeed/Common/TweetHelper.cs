﻿using System;
using System.Collections.Generic;
using System.IO;
using TwitterFeed.Common;
using TwitterFeed.Model;

namespace TwitterFeed
{
    public class TweetHelper : UserHelper
    {
        List<TwitterModel> twitterModel = new List<TwitterModel>();

        /// <summary>
        /// 1. Gets the data from the tweet file 
        /// 2. Breaks up the data into sections, "users" and "tweets"
        /// 3. Adds the data to the TwitterModel 
        /// </summary>
        /// <returns></returns>
        public List<TwitterModel> GetTweets()
        {
            try
            {
                var path = FileHelper.TwitterFilePath;
                if (!string.IsNullOrEmpty(path))
                {
                    if (File.Exists(path))
                    {
                        foreach (string line in File.ReadLines(path))
                        {
                            var items = line.Split('>');

                            twitterModel.Add(new TwitterModel
                            {
                                UserName = items[0],
                                Tweet = items[1]
                            });
                        }
                    }
                }
                else if (string.IsNullOrEmpty(path))
                {
                    Console.WriteLine("Please specify a path to the tweet.txt file"
                                      + Environment.NewLine + path
                                      + Environment.NewLine + "Press (M) for Menu or any key to exit");
                }

                return twitterModel;
            }
            catch (Exception ex)
            {
                ExceptionHelper exHelper = new ExceptionHelper();
                exHelper.LogException(ex.ToString(), "TweeterHelper");
                return twitterModel;
            }
        }
    }
}
