﻿using System;
using System.IO;

namespace TwitterFeed.Common
{
    public class ExceptionHelper
    {
        /// <summary>
        /// Catches the exception and writes it to a txt file.
        /// The location for the file will be the same as the one selected for the user file.
        /// </summary>
        /// <param name="exception"></param>
        /// <param name="location"></param>
        public void LogException(string exception, string location)
        {
            var date = DateTime.UtcNow.ToString("yyyyMMddHHmmss");
            var path = FileHelper.UserFilePath.Substring(0, FileHelper.UserFilePath.LastIndexOf('\\')); 
            var fullPath = path + "\\" + date +  "- ErrorLog.txt";
            File.WriteAllText(fullPath, exception + Environment.NewLine + "Location oF Error: " + location);
            Console.WriteLine("An error has occured! Please review the below file." + Environment.NewLine + fullPath);
        }
    }
}
