﻿using System;
using System.Collections.Generic;
using System.Linq;
using TwitterFeed.Model;

namespace TwitterFeed.Common
{
    public class DisplayHelper : TweetHelper
    {
        /// <summary>
        /// Builds up a Display of Users, there Tweets and who they Follow 
        /// </summary>
        public bool GetUsersAndTweets(bool isUnitTest = false)
        {
            try
            {
                #region Get User & Twitter File Paths from User
                bool getFilesMenu = true;
                var outcomeValue = string.Empty;
                while (getFilesMenu)
                {
                    getFilesMenu = FileHelper.GetUsersAndTweetsFile(isUnitTest);
                }
                #endregion

                List<UserModel> userModel = GetUsers();
                List<TwitterModel> twitterModel = GetTweets();
                List<DisplayModal> displayModal = new List<DisplayModal>();
                List<string> allTwitterUsers = GetAllUsers(userModel);
                string user = string.Empty;
                bool hasTweets = false;

                foreach (var itemUser in allTwitterUsers.Distinct())
                {
                    user = itemUser;
                    List<string> tweet = new List<string>();

                    foreach (var itemTwitter in twitterModel)
                    {
                        if (itemTwitter.UserName.Equals(itemUser, StringComparison.InvariantCultureIgnoreCase))//Has the user tweeted?
                        {
                            if (!tweet.Contains(itemTwitter.Tweet))//Does the tweet exist in the collection?
                            {
                                tweet.Add(itemTwitter.Tweet);//No, add the Tweet
                            }

                        }
                    }

                    displayModal.Add(new DisplayModal // Add the twitter user and there tweets to the Display Model
                    {
                        User = user,
                        Tweet = tweet
                    });
                }

                IEnumerable<DisplayModal> orderedByUser = displayModal.OrderBy(p => p.User);//Order by user

                foreach (var item in orderedByUser)
                {
                    hasTweets = false;
                    Console.WriteLine(item.User);
                    foreach (var itemTweet in item.Tweet)
                    {
                        if (itemTweet.Length > 140)
                        {
                            Console.WriteLine("\t" + "@" + item.User + ":" + "Character count limit exceeded ({0}){1}",itemTweet.Length ," the limit is 140");
                        }
                        else
                        {
                            Console.WriteLine("\t" + "@" + item.User + ":" + itemTweet);
                        }
                        
                        hasTweets = true;
                    }
                    if (!hasTweets)
                    {
                        Console.WriteLine("\t" + "@" + item.User + ":" + " Has no Tweets");
                    }
                }

                Console.WriteLine("Press (M) for Menu or any key to exit");
                if (isUnitTest)
                {
                    outcomeValue = "m";
                }
                else
                {
                    outcomeValue = Console.ReadLine();
                }

                return Outcome(outcomeValue);
            }
            catch (Exception ex)
            {
                ExceptionHelper exHelper = new ExceptionHelper();
                exHelper.LogException(ex.ToString(), "DisplayHelper > GetUsersAndTweets");
                return true;
            }
        }
        /// <summary>
        /// Builds up a display of the user(s) and who they follow
        /// </summary>
        /// <returns></returns>
        public bool GetUsersAndFollowers(bool isUnitTest = false)
        {
            try
            {
                #region Get User File Paths from User
                bool getFilesMenu = true;
                var outcomeValue = string.Empty;

                while (getFilesMenu)
                {
                    getFilesMenu = FileHelper.GetUsersFile(isUnitTest);
                }
                #endregion

                List<UserModel> userModel = GetUsers();
                List<string> allUsers = GetAllUsers(userModel);
                List<string> allFollowers = new List<string>();

                foreach (var itemUser in allUsers.Distinct())//Loop through distinct users
                {
                    Console.WriteLine("@"+itemUser + " is following:");
                    foreach (var item in userModel)
                    {
                        if (item.UserName.Equals(itemUser))//Find the user record
                        {
                            if (item.FollowedUsers.Contains(",")) 
                            {
                                foreach (var follower in item.FollowedUsers.Split(','))
                                {
                                    var trimmedFollower = Sanitizer(follower);//Remove's empty spaces on either side of the string 
                                    if (!allFollowers.Contains(trimmedFollower))
                                    {
                                        Console.WriteLine("\t\t\t" + trimmedFollower);
                                        allFollowers.Add(Sanitizer(follower));
                                    }
                                }
                            }
                            else
                            {
                                Console.WriteLine("\t\t\t" + item.FollowedUsers);
                            }
                                allFollowers.Add(Sanitizer(item.FollowedUsers));
                        }
                        
                    }

                    allFollowers = new List<string>();
                }

                Console.WriteLine("Press (M) for Menu or any key to exit");
                if (isUnitTest)
                {
                    outcomeValue = "m";
                }
                else
                {
                    outcomeValue = Console.ReadLine();
                }

                return Outcome(outcomeValue);
            }
            catch (Exception ex)
            {
                ExceptionHelper exHelper = new ExceptionHelper();
                exHelper.LogException(ex.ToString(), "DisplayHelper > GetUsersAndFollowers");
                return true;
            }
        }
        /// <summary>
        /// Validates if the User has selected to show the Main Menu screen
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public bool Outcome(string value)
        {
            bool action = false;

            if (value.ToLower().Equals("m"))
            {
                action = true;
            }
            else
            {
                action = false;
            }

            return action;
        }
        /// <summary>
        /// Builds up a collection of all the users i.e. the users and there followers 
        /// </summary>
        /// <param name="userModel"></param>
        /// <returns></returns>
        public List<string> GetAllUsers(List<UserModel> userModel)
        {
            List<string> allTwitterUsers = new List<string>();
            string user = string.Empty;

            foreach (var item in userModel)
            {
                allTwitterUsers.Add(Sanitizer(item.UserName));
                if (item.FollowedUsers.Contains(','))
                {
                    foreach (var x in item.FollowedUsers.Split(','))
                    {
                        allTwitterUsers.Add(Sanitizer(x));
                    }
                }
                else
                {
                    allTwitterUsers.Add(Sanitizer(item.FollowedUsers));
                }
            }

            return allTwitterUsers;
        }

        /// <summary>
        /// Removes empty spaces
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public new string Sanitizer(string value)
        {
            return value.Replace(" ", string.Empty);
        }
    }
}
