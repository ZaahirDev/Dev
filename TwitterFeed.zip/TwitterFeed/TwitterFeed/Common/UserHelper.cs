﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using TwitterFeed.Common;
using TwitterFeed.Model;

namespace TwitterFeed
{
    public class UserHelper
    {
        /// <summary>
        /// 1. Gets the data from the user file 
        /// 2. Breaks up the data into sections, "users", "action" and "followed users"
        /// 3. Adds the data to the UserModel 
        /// </summary>
        /// <returns></returns>
        public List<UserModel> GetUsers()
        {
            List<UserModel> userProperties = new List<UserModel>();
            try
            {
                int counter = 0;
                var path = FileHelper.UserFilePath;

                if (!string.IsNullOrEmpty(path))
                {
                    string name = string.Empty;
                    string action = string.Empty;
                    string followedUsers = string.Empty;
                    List<string> allUsers = new List<string>();
                    if (File.Exists(path))
                    {
                        foreach (string line in File.ReadLines(path))
                        {
                            var items = line.Split(' '); //Do a split on a space

                            foreach (var item in items)
                            {
                                if (item.ToLower().Equals("follows"))
                                {
                                    action = item;
                                }
                                else if (item.ToLower().Contains(',') || counter >= 2)
                                {
                                    followedUsers += item + " ";
                                }
                                else
                                {
                                    name = item;
                                }

                                counter++;
                            }

                            userProperties.Add(new UserModel
                            {
                                UserName = name,
                                Action = action,
                                FollowedUsers = followedUsers
                            });

                            name = string.Empty;
                            action = string.Empty;
                            followedUsers = string.Empty;
                            counter = 0;
                        }

                        counter++;

                    }
                }
                else if (string.IsNullOrEmpty(path))
                {
                    Console.WriteLine("Please specify a path to the user.txt file"
                                      + Environment.NewLine + path
                                      + Environment.NewLine + "Press (M) for Menu or (X) to exit the application");
                }
                return userProperties;
            }
            catch (Exception ex)
            {
                ExceptionHelper exHelper = new ExceptionHelper();
                exHelper.LogException(ex.ToString(), "UserHelper");
                return userProperties;
            }

        }
        
        /// <summary>
        /// Removes empty spaces
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public string Sanitizer(string value)
        {
            return value.Replace(" ", string.Empty);
        }


    }
}
